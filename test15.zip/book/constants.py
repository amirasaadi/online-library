MAX_BOOK_LOAN = 4
LOAN_TIME     = 14  # days
NEAR          = 3 #d days
